<template>
  <div>专区</div>
</template>

<script>
  export default {
    name: "SpecialArea"
  }
</script>

<style scoped>

</style>