<template>
  <div>推广</div>
</template>

<script>
  export default {
    name: "Generalize"
  }
</script>

<style scoped>

</style>