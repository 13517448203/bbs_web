import {request} from "./request";

/**
 *  请求首页综合帖子数据
 */
export function getHomePostData(forumTypeId) {
  return request({
    url: '/BBS/forum/queryall.action',
    post: 'post',
    param:{
      forumTypeId
    }
  })
}

/**
 *  请求首页精华帖子数据
 */
export function getHomeBestPostData() {
  return request({
    url: '/BBS/forum/queryplus.action',
    post: 'post'
  })
}

/**
 *  请求首页置顶数据
 */
export function getHomeTopData() {
  return request({
    url: '/BBS/forum/querytop.action',
    post: 'post'
  })
}

/**
 *  请求热议数据
 */
export function getHomeWeeksHotData() {
  return request({
    url: '/BBS/forum/queryweek.action',
    post: 'post'
  })
}

/**
 *  请求提问,数据
 */
export function getHomeQueData(index) {
  return request({
    url: '/BBS/forum/queryweek.action',
    post: 'post',
    param:{
      index
    }
  })
}

