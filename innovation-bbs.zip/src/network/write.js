import {request} from "./request";

/**
 *  请求首页精华帖子数据
 */
export function upPostContent(content) {
  return request({
    url: '/BBS/forum/insert.action',
    post: 'post',
    param:{
      userName: content.userName,
      forumTitle: content.forumTitle,
      forumPath: content.forumPath,
      forumTypeId: content.forumTypeId
    }
  })
}